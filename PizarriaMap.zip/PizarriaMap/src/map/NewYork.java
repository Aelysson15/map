package map;

public class NewYork implements Pizza{
	@Override
	public void exibeinfo() {
		System.out.println("NY : Queijo");
		
	}
}

