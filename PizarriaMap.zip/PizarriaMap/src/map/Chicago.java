package map;

 class Chicago{
	
	
	public abstract class PizzaStore{
		abstract Pizza criaPizza(String item);
		
		public Pizza pizza(String tipo){
			Pizza pizza = criaPizza(tipo);
			
			return pizza;
		}
	}
	
	abstract class ChicagoPizzaQueijo implements Pizza{

		public String showInfo() { 
			return "ChicagoPizzaQueijo"; 
		}
	}
	abstract class ChicagoPizzaPeperone implements Pizza{

		public String showInfo() { 
			return "ChicagoPizzaPeperone"; 
		}
	}
}
