package map;

public class Pizzaria implements DependentPizzaStore{
	private String estilo;
	private String tipo;
	
	@Override
	public Pizza CriaPizza(String estilo, String tipo) {
		if (tipo.equals("cheese")) {
			return (Pizza) new Chicago();
			
			
			
		}else if(tipo.equals("vegge")){
			 return new NewYork();
		}
		else {
			return null;
		}
		
	}
	
	
}
