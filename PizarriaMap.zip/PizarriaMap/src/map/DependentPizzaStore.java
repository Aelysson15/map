package map;

public interface DependentPizzaStore {

	Pizza CriaPizza(String estilo, String tipo);
}
