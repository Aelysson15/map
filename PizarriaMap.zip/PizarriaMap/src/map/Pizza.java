package map;

public interface Pizza {
	void exibeinfo();
}
